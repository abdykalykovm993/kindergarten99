package kg.mega.kindergarten;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KindergartenApplicationTests {

    @Test
    void contextLoads() {
    }

}
