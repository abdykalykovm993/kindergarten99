package kg.mega.kindergarten.controllers;

import io.swagger.v3.oas.annotations.Operation;
import kg.mega.kindergarten.controllers.cruds.CRUDController;
import kg.mega.kindergarten.models.dtos.ChildGroupHistoryCreateDto;
import kg.mega.kindergarten.models.dtos.ChildGroupHistoryDto;
import kg.mega.kindergarten.models.dtos.ChildGroupHistoryUpdateDto;
import kg.mega.kindergarten.services.ChildGroupHistoryService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping ("/api/child-group-history")
public class ChildGroupHistoryController implements CRUDController<ChildGroupHistoryDto, ChildGroupHistoryCreateDto, ChildGroupHistoryUpdateDto> {

    private final ChildGroupHistoryService childGroupHistoryService;


    public ChildGroupHistoryController(ChildGroupHistoryService childGroupHistoryService) {
        this.childGroupHistoryService = childGroupHistoryService;
    }


    @PostMapping ("/create")
    @Operation (summary = "Сохранение истории ребенка", description = "Сохранение истории ребенка, его группы")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public ChildGroupHistoryDto create( ChildGroupHistoryCreateDto childGroupHistoryCreateDto) {
        return childGroupHistoryService.create (childGroupHistoryCreateDto);
    }

    @PutMapping ("/update/ {id}")
    @Operation (summary = "Обновление истории ребенка")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public ChildGroupHistoryDto update(@PathVariable Long id, ChildGroupHistoryUpdateDto updatedDto) {
        return childGroupHistoryService.update (id, updatedDto);
    }


    @DeleteMapping ("/delete/{id}")
    @Operation (summary = "Удаление истории ребенка")
    @Override
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")

    public ResponseEntity<?> delete(@PathVariable Long id) {
        return childGroupHistoryService.delete (id);
    }

    @GetMapping ("/get/all")
    @Operation (summary = "Получение списка всей истории")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public List<ChildGroupHistoryDto> allList(@RequestParam int page, @RequestParam int size) {
        return childGroupHistoryService.getAll (page, size);
    }



    @GetMapping ("/get/{id}")
    @Operation (summary = "Поиск информации о ребенке по id")
    @Override
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")

    public ChildGroupHistoryDto findById(@PathVariable Long id) {
        return childGroupHistoryService.findById (id);
    }
}
