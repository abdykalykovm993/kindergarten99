package kg.mega.kindergarten.mappers;

import kg.mega.kindergarten.models.AgeGroup;
import kg.mega.kindergarten.models.Group;
import kg.mega.kindergarten.models.dtos.GroupCreateDto;
import kg.mega.kindergarten.models.dtos.GroupDto;
import kg.mega.kindergarten.models.dtos.GroupUpdateDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface GroupMapper {

    GroupMapper INSTANCE = Mappers.getMapper(GroupMapper.class);

    @Mapping(source = "ageGroup", target = "ageGroup")
    @Mapping(source = "groupCreateDto.name", target = "name")
    @Mapping(target = "id", ignore = true)
    Group groupCreateDto(GroupCreateDto groupCreateDto, AgeGroup ageGroup);
    GroupDto groupCreateDto(Group group);

    @Mapping(target = "id", ignore = true)
    @Mapping(source = "groupUpdateDto.name", target = "name")
    @Mapping(source = "ageGroup", target = "ageGroup")
    Group groupUpdateDto(GroupUpdateDto groupUpdateDto, AgeGroup ageGroup);
    List <GroupDto> groupToGroupDtoList(List<Group> groups);
}
