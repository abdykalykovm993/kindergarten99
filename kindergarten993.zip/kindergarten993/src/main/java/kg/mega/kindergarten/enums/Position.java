package kg.mega.kindergarten.enums;

public enum Position {
    TEACHER,
    ASSISTANT
}
