package kg.mega.kindergarten.enums;

public enum PaymentType {
    CASH,
    QR,
    CARD,
    TRANSFER
}
