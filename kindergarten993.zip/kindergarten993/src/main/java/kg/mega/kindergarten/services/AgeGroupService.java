package kg.mega.kindergarten.services;

import kg.mega.kindergarten.models.AgeGroup;
import kg.mega.kindergarten.models.dtos.AgeGroupCreateDto;
import kg.mega.kindergarten.models.dtos.AgeGroupDto;
import kg.mega.kindergarten.models.dtos.AgeGroupUpdateDto;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface AgeGroupService {
    AgeGroupDto create(AgeGroupCreateDto ageGroupCreateDto);

    AgeGroup findById(Long aLong);

    AgeGroupDto updateById(Long ageGroupId, AgeGroupUpdateDto ageGroupUpdateDto);

    ResponseEntity<?> deleteById(Long ageGroupId);

    List<AgeGroupDto> getAll(int page, int size);

    AgeGroupDto findByIdAndReturnDto(Long id);
}
