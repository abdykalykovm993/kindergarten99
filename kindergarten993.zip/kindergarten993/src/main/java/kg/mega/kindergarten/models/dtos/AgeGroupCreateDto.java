package kg.mega.kindergarten.models.dtos;

public record AgeGroupCreateDto (
        String name,
        double price,
        boolean active
){
}
