package kg.mega.kindergarten.mappers;

import kg.mega.kindergarten.models.Contact;
import kg.mega.kindergarten.models.Parent;
import kg.mega.kindergarten.models.dtos.ParentCreateDto;
import kg.mega.kindergarten.models.dtos.ParentDto;
import kg.mega.kindergarten.models.dtos.ParentUpdateDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface ParentMapper {

    ParentMapper INSTANCE = Mappers.getMapper(ParentMapper.class);

    @Mapping(source = "contact", target = "contact")
    @Mapping(target = "id", ignore = true)
    Parent parentCreateDtoToParent(ParentCreateDto parentCreateDto, Contact contact);
    ParentDto parentToParentDto(Parent parent);
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "contact", ignore = true)
    @Mapping(target = "active", ignore = true)
    void updateParentFromDto(ParentUpdateDto parentUpdateDto, @MappingTarget Parent parent);
    @Mapping(source = "id", target = "parentId")
    List<ParentDto> parentsToParentDtos(List<Parent> parents);
}
