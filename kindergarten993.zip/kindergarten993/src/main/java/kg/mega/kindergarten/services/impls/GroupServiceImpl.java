package kg.mega.kindergarten.services.impls;

import kg.mega.kindergarten.mappers.GroupMapper;
import kg.mega.kindergarten.models.AgeGroup;
import kg.mega.kindergarten.models.Child;
import kg.mega.kindergarten.models.Group;
import kg.mega.kindergarten.models.dtos.*;
import kg.mega.kindergarten.repositories.GroupRepo;
import kg.mega.kindergarten.services.AgeGroupService;
import kg.mega.kindergarten.services.ChildService;
import kg.mega.kindergarten.services.GroupService;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service

public class GroupServiceImpl implements GroupService {
    private final GroupRepo groupRepo;
    private final AgeGroupService ageGroupService;

    public GroupServiceImpl(GroupRepo groupRepo, AgeGroupService ageGroupService) {
        this.groupRepo = groupRepo;
        this.ageGroupService = ageGroupService;
    }



    @Override
    public GroupDto create(GroupCreateDto groupCreateDto) {
        AgeGroup ageGroup = ageGroupService.findById (groupCreateDto.ageGroupId());
        Group group = GroupMapper.INSTANCE.groupCreateDto(groupCreateDto, ageGroup);
        group = groupRepo.save(group);
        return GroupMapper.INSTANCE.groupCreateDto(group);
    }

    @Override
    public Group findById(Long groupId) {
        return groupRepo.findById(groupId).orElseThrow();
    }

    @Override
    public GroupDto update(Long id, GroupUpdateDto updatedDto) {
        AgeGroup ageGroup = ageGroupService.findById (updatedDto.ageGroup());
        Group group = groupRepo.findById(id).orElseThrow( ()-> new RuntimeException("Группа по данному id не найдена"));
        group = GroupMapper.INSTANCE.groupUpdateDto(updatedDto, ageGroup);
        group = groupRepo.save(group);
        return GroupMapper.INSTANCE.groupCreateDto(group);
    }

    @Override
    public ResponseEntity<?> delete(Long id) {
        Group group = groupRepo.findById(id).orElseThrow(()-> new RuntimeException("Группа не найдена"));
        groupRepo.delete(group);
        return ResponseEntity.ok().build();
    }

    @Override
    public List<GroupDto> getAll(int page, int size) {
        Pageable pageable = PageRequest.of (page, size);
        List <Group> groups = groupRepo.findAll(pageable).stream().toList();
        return GroupMapper.INSTANCE.groupToGroupDtoList(groups);
    }

    @Override
    public GroupDto findByIdAndReturnDto(Long id) {
        Group group = groupRepo.findById( id).orElseThrow(() -> new RuntimeException("Группа не найдена"));
        return GroupMapper.INSTANCE.groupCreateDto(group);
    }
}
