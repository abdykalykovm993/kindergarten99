package kg.mega.kindergarten.controllers.cruds;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

public interface CRUDController <Dto, CreateDto, UpdateDto>{
    Dto create(@Valid @RequestBody CreateDto dto);
    Dto update( Long id, @Valid @RequestBody UpdateDto updatedDto);
    ResponseEntity<?> delete(@RequestParam Long id);
    List<Dto> allList(@RequestParam int page, @RequestParam int size);
    Dto findById(@RequestParam Long id);

}
