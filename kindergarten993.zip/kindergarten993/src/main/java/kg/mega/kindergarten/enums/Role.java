package kg.mega.kindergarten.enums;

public enum Role {
    FATHER,
    MOTHER,
    BROTHER,
    SISTER
}
