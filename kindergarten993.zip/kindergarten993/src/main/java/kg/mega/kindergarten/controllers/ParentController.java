package kg.mega.kindergarten.controllers;

import io.swagger.v3.oas.annotations.Operation;
import kg.mega.kindergarten.controllers.cruds.CRUDController;
import kg.mega.kindergarten.models.dtos.ParentCreateDto;
import kg.mega.kindergarten.models.dtos.ParentDto;
import kg.mega.kindergarten.models.dtos.ParentUpdateDto;
import kg.mega.kindergarten.services.ParentService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping ("/api/parent")
public class ParentController implements CRUDController<ParentDto, ParentCreateDto, ParentUpdateDto> {

    private final ParentService parentService;

    public ParentController(ParentService parentService) {
        this.parentService = parentService;
    }

    @PostMapping ("/create")
    @Operation (summary = "Создание родителя")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public ParentDto create(ParentCreateDto parentCreateDto) {
        return parentService.create (parentCreateDto);
    }

    @PutMapping ("/update/{parentId}")
    @Operation (summary = "Обновление родителя")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public ParentDto update(@PathVariable Long parentId,ParentUpdateDto parentUpdateDto) {
        return parentService.update (parentId, parentUpdateDto);
    }

    @DeleteMapping ("/delete/ {id}")
    @Operation (summary = "Удаление родителя")
    @Override
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")

    public ResponseEntity<?> delete(@PathVariable Long id) {
        return parentService.deleteById (id);
    }

    @GetMapping ("/get/all")
    @Operation (summary = "Получение всех родителей")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public List<ParentDto> allList( int page, int size) {
        return parentService.findAll ( page, size);
    }


    @GetMapping ("/get/{parentId}")
    @Operation (summary = "Получение родителя по id")
    @Override
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")

    public ParentDto findById(@PathVariable Long parentId) {
        return parentService.findById (parentId);
    }
}
