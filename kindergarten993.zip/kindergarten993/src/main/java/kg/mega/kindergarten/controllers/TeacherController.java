package kg.mega.kindergarten.controllers;

import io.swagger.v3.oas.annotations.Operation;
import kg.mega.kindergarten.controllers.cruds.CRUDController;
import kg.mega.kindergarten.mappers.TeacherMapper;
import kg.mega.kindergarten.models.Teacher;
import kg.mega.kindergarten.models.dtos.TeacherCreateDto;
import kg.mega.kindergarten.models.dtos.TeacherDto;
import kg.mega.kindergarten.models.dtos.TeacherUpdateDto;
import kg.mega.kindergarten.services.TeacherService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping ("/api/teacher")
public class TeacherController implements CRUDController<TeacherDto, TeacherCreateDto, TeacherUpdateDto> {

    private final TeacherService teacherService;

    public TeacherController(TeacherService teacherService) {
        this.teacherService = teacherService;
    }

    @PostMapping ("/create")
    @Operation (summary = "Создание учителя")
    @Override
    @PreAuthorize("hasRole('ADMIN')")
    public TeacherDto create(@RequestBody  TeacherCreateDto teacherCreateDto) {
        return teacherService.create (teacherCreateDto);
    }

    @PutMapping ("/update/{teacherId}")
    @Operation (summary = "Обновление учителя")
    @Override
    @PreAuthorize("hasRole('ADMIN')")
    public TeacherDto update(@PathVariable Long teacherId,TeacherUpdateDto teacherUpdateDto) {
        return teacherService.update (teacherId,teacherUpdateDto);
    }

    @DeleteMapping ("/delete/{id}")
    @Operation (summary = "Удаление учителя")
    @Override
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity <?> delete(@PathVariable Long id) {
        return teacherService.delete (id);
    }

    @GetMapping ("/get/all")
    @Operation (summary = "Получение списка всех учителей по страницам")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public List<TeacherDto> allList(int page, int size) {

        return teacherService.getAllTeachers (page, size);
    }

    @GetMapping ("/get/{teacherId}")
    @Operation (summary = "Поиск учителя по id")
    @Override
    @PreAuthorize("hasRole('ADMIN')")
    public TeacherDto findById(@PathVariable Long teacherId) {
        return teacherService.findByIdAndReturnDto(teacherId);
    }

}
