package kg.mega.kindergarten.models.dtos;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Positive;
import kg.mega.kindergarten.enums.Position;

import java.time.LocalDate;

public record TeacherUpdateDto(
        @Positive
        Long contactId,
        @NotNull
        Position position,
        @Past
        LocalDate dateOfBirth,
        String firstName,
        String lastName,
        String patronymic

){
}
