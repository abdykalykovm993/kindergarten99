package kg.mega.kindergarten.models.dtos;

public record GroupUpdateDto(
        String name,
        Long ageGroup
){
}
