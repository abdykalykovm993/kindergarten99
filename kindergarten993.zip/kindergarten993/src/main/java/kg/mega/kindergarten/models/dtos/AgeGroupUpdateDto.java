package kg.mega.kindergarten.models.dtos;

public record AgeGroupUpdateDto(
        String name,
        double price,
        boolean active
){
}
