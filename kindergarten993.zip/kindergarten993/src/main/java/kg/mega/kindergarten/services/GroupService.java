package kg.mega.kindergarten.services;

import kg.mega.kindergarten.models.Group;
import kg.mega.kindergarten.models.dtos.*;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface GroupService {
    GroupDto create(GroupCreateDto groupCreateDto);

    Group findById(Long groupId);

    GroupDto update(Long id, GroupUpdateDto updatedDto);

    ResponseEntity<?> delete(Long id);

    List<GroupDto> getAll(int page, int size);

    GroupDto findByIdAndReturnDto(Long id);
}
