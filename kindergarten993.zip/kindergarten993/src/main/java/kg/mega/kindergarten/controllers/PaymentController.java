package kg.mega.kindergarten.controllers;

import io.swagger.v3.oas.annotations.Operation;
import kg.mega.kindergarten.controllers.cruds.CRUDController;
import kg.mega.kindergarten.models.dtos.PaymentCreateDto;
import kg.mega.kindergarten.models.dtos.PaymentDto;
import kg.mega.kindergarten.models.dtos.PaymentUpdateDto;
import kg.mega.kindergarten.services.PaymentService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping ("/api/payment")
public class PaymentController implements CRUDController<PaymentDto, PaymentCreateDto, PaymentUpdateDto> {


    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping ("/create")
    @Operation (summary = "Создание транзакции", description = "Создание транзакции для ребенка")
    @Override
    @PreAuthorize("hasRole('ADMIN')")
    public PaymentDto create(PaymentCreateDto paymentCreateDto) {
        return paymentService.create (paymentCreateDto);
    }


    @PutMapping ("/update/{paymentId}")
    @Operation (summary = "Обновление оплаты")
    @Override
    @PreAuthorize("hasRole('ADMIN')")
    public PaymentDto update(@PathVariable Long paymentId, PaymentUpdateDto paymentUpdateDto) {
        return paymentService.update (paymentId,paymentUpdateDto);
    }


    @DeleteMapping ("/delete")
    @Operation (summary = "Удаление оплаты")
    @Override
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")
    public ResponseEntity<?> delete(Long id) {
        return paymentService.deletePaymentById (id);
    }

    @GetMapping ("/get/all")
    @Operation (summary = "Получение всех оплат", description = "Получение всех оплат постранично")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public List<PaymentDto> allList(int page, int size) {
        return paymentService.getAllPayments (page, size);
    }


    @GetMapping ("/get/{id}")
    @Operation (summary = "Поиск оплаты по id")
    @Override
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")
    public PaymentDto findById(@RequestParam Long paymentId) {
        return paymentService.findPaymentById (paymentId);
    }

    @GetMapping("/get-payments-by-period/{childId}")
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")
    public ResponseEntity<?> getPaymentsByPeriod(@RequestParam @DateTimeFormat(pattern = "dd.MM.yyyy") LocalDate startDate, @RequestParam @DateTimeFormat(pattern = "dd.MM.yyyy") LocalDate endDate, @PathVariable Long childId) {
        return ResponseEntity.ok(paymentService.getPaymentsByPeriod(startDate, endDate, childId));
    }

}
