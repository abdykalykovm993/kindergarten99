package kg.mega.kindergarten.controllers;

import io.swagger.v3.oas.annotations.Operation;
import kg.mega.kindergarten.controllers.cruds.CRUDController;
import kg.mega.kindergarten.models.dtos.ContactCreateDto;
import kg.mega.kindergarten.models.dtos.ContactDto;
import kg.mega.kindergarten.models.dtos.ContactUpdateDto;
import kg.mega.kindergarten.services.ContactService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping ("/api/contact")
public class ContactController implements CRUDController<ContactDto, ContactCreateDto, ContactUpdateDto> {

    private final ContactService contactService;

    public ContactController(ContactService contactService) {
        this.contactService = contactService;
    }

    @PostMapping ("/create")
    @Operation (summary = "Создание контакта")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public ContactDto create(@RequestBody ContactCreateDto contactCreateDto) {
        return contactService.create (contactCreateDto);
    }


    @PutMapping ("/update/{id}")
    @Operation (summary = "Обновление контакта")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public ContactDto update(@PathVariable Long id, @RequestBody ContactUpdateDto updatedDto) {
        return contactService.update (id, updatedDto);
    }

    @DeleteMapping ("/delete/{id}")
    @Operation (summary = "Удаление контакта по id")
    @Override
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")

    public ResponseEntity<?> delete(@PathVariable Long id) {
        return contactService.delete (id);
    }

    @GetMapping ("/get/all")
    @Operation (summary = "Получение всех контактов по страницам")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public List<ContactDto> allList(@RequestParam  int page, @RequestParam int size) {
        return contactService.getAll (page, size);
    }

    @GetMapping ("/contact/{id}")
    @Operation (summary = "Поиска контакта по id")
    @Override
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")

    public ContactDto findById(@PathVariable Long id) {
        return contactService.findByIdAndReturnDto(id);
    }
}
