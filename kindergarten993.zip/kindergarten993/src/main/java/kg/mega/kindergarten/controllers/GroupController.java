package kg.mega.kindergarten.controllers;

import io.swagger.v3.oas.annotations.Operation;
import kg.mega.kindergarten.controllers.cruds.CRUDController;
import kg.mega.kindergarten.models.dtos.GroupCreateDto;
import kg.mega.kindergarten.models.dtos.GroupDto;
import kg.mega.kindergarten.models.dtos.GroupUpdateDto;
import kg.mega.kindergarten.services.GroupService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping ("/api/group")
public class GroupController implements CRUDController<GroupDto, GroupCreateDto, GroupUpdateDto> {

    private final GroupService groupService;

    public GroupController(GroupService groupService) {
        this.groupService = groupService;
    }

    @PostMapping ("/create")
    @Operation (summary = "Создание группы")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public GroupDto create(GroupCreateDto groupCreateDto) {
        return groupService.create(groupCreateDto);
    }

    @PutMapping ("/update/{id}")
    @Operation (summary = "Обновление группы")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public GroupDto update(@PathVariable Long id, @RequestBody GroupUpdateDto updatedDto) {
        return groupService.update (id, updatedDto);
    }

    @DeleteMapping ("/delete/{id}")
    @Operation (summary = "Удаление группы")
    @Override
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")

    public ResponseEntity<?> delete(@PathVariable Long id) {
        return groupService.delete (id);
    }

    @GetMapping ("/get/all")
    @Operation (summary = "Получение всех групп по страницам")
    @Override
    @PreAuthorize("hasRole('ADMIN')")

    public List<GroupDto> allList(@RequestParam int page, @RequestParam int size) {
        return groupService.getAll(page, size);
    }


    @GetMapping ("/get/{id}")
    @Operation (summary = "Получение контакта по id")
    @Override
    @PreAuthorize("hasAnyRole('ADMIN', 'TEACHER')")

    public GroupDto findById(@PathVariable Long id) {
        return groupService.findByIdAndReturnDto(id);
    }
}
