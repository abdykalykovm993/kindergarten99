package kg.mega.kindergarten.models.dtos;

import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import kg.mega.kindergarten.models.AgeGroup;

public record GroupDto (
        Long id,
        String name,
        AgeGroupDto ageGroup
){
}
